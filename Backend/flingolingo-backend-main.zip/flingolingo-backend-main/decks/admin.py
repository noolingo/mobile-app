from django.contrib import admin

from .models import Deck, Progress

# Register your models here.
admin.site.register(Deck)
admin.site.register(Progress)